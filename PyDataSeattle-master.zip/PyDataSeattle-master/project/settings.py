DOMAIN = {'matches': {}}
MONGO_DBNAME = 'dota'
